/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package cinema;

import java.awt.Color;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Set;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author nc
 */
public class SeatPlan extends javax.swing.JFrame {

    /**
     * Creates new form SeatPlan
     */
    public int click_count=0;
    public Hashtable<String,Seat> seat_list=new Hashtable<>();
    public Set<String> sold_seat_list=new HashSet<String>();
    public static JButton selectedSeat=null;
    
    public static int price=0;
    
    public SeatPlan() {
        initComponents();
        
        //
        //populate seats
        seat_list.put("A1",new Seat("A1","Single",5000,true));
        seat_list.put("A2",new Seat("A2","Single",5000,true));
        seat_list.put("A3",new Seat("A3","Single",5000,true));
        seat_list.put("A4",new Seat("A4","Single",5000,true));
        seat_list.put("A5",new Seat("A5","Single",5000,true));
        seat_list.put("A6",new Seat("A6","Single",5000,true));
        seat_list.put("A7",new Seat("A7","Single",5000,true));
        seat_list.put("A8",new Seat("A8","Single",5000,true));
        seat_list.put("A9",new Seat("A9","Single",5000,true));
        seat_list.put("A10",new Seat("A10","Single",5000,true));
        
        
        seat_list.put("B1",new Seat("B1","Single",5000,true));
        seat_list.put("B2",new Seat("B2","Single",5000,true));
        seat_list.put("B3",new Seat("B3","Single",5000,true));
        seat_list.put("B4",new Seat("B4","Single",5000,true));
        seat_list.put("B5",new Seat("B5","Single",5000,true));
        seat_list.put("B6",new Seat("B6","Single",5000,true));
        seat_list.put("B7",new Seat("B7","Single",5000,true));
        seat_list.put("B8",new Seat("B8","Single",5000,true));
        seat_list.put("B9",new Seat("B9","Single",5000,true));
        seat_list.put("B10",new Seat("B10","Single",5000,true));
        
        
        seat_list.put("C1",new Seat("C1","Single",5000,true));
        seat_list.put("C2",new Seat("C2","Single",5000,true));
        seat_list.put("C3",new Seat("C3","Single",5000,true));
        seat_list.put("C4",new Seat("C4","Single",5000,true));
        seat_list.put("C5",new Seat("C5","Single",5000,true));
        seat_list.put("C6",new Seat("C6","Single",5000,true));
        seat_list.put("C7",new Seat("C7","Single",5000,true));
        seat_list.put("C8",new Seat("C8","Single",5000,true));
        seat_list.put("C9",new Seat("C9","Single",5000,true));
        seat_list.put("C10",new Seat("C10","Single",5000,true));
        
        
        seat_list.put("D1",new Seat("D1","Single",5000,true));
        seat_list.put("D2",new Seat("D2","Single",5000,true));
        seat_list.put("D3",new Seat("D3","Single",5000,true));
        seat_list.put("D4",new Seat("D4","Single",5000,true));
        seat_list.put("D5",new Seat("D5","Single",5000,true));
        seat_list.put("D6",new Seat("D6","Single",5000,true));
        seat_list.put("D7",new Seat("D7","Single",5000,true));
        seat_list.put("D8",new Seat("D8","Single",5000,true));
        seat_list.put("D9",new Seat("D9","Single",5000,true));
        seat_list.put("D10",new Seat("D10","Single",5000,true));
        
        
        seat_list.put("E1",new Seat("E1","Single",5000,true));
        seat_list.put("E2",new Seat("E2","Single",5000,true));
        seat_list.put("E3",new Seat("E3","Single",5000,true));
        seat_list.put("E4",new Seat("E4","Single",5000,true));
        seat_list.put("E5",new Seat("E5","Single",5000,true));
        seat_list.put("E6",new Seat("E6","Single",5000,true));
        seat_list.put("E7",new Seat("E7","Single",5000,true));
        seat_list.put("E8",new Seat("E8","Single",5000,true));
        seat_list.put("E9",new Seat("E9","Single",5000,true));
        seat_list.put("E10",new Seat("E10","Single",5000,true));
        
        
        seat_list.put("F1",new Seat("F1","VIP",8000,true));
        seat_list.put("F2",new Seat("F2","VIP",8000,true));
        seat_list.put("F3",new Seat("F3","VIP",8000,true));
        seat_list.put("F4",new Seat("F4","VIP",8000,true));
        seat_list.put("F5",new Seat("F5","VIP",8000,true));
        seat_list.put("F6",new Seat("F6","VIP",8000,true));
        seat_list.put("F7",new Seat("F7","VIP",8000,true));
        seat_list.put("F8",new Seat("F8","VIP",8000,true));
        seat_list.put("F9",new Seat("F9","VIP",8000,true));
        seat_list.put("F10",new Seat("F10","VIP",8000,true));
        
        
        seat_list.put("G1",new Seat("G1","VIP",8000,true));
        seat_list.put("G2",new Seat("G2","VIP",8000,true));
        seat_list.put("G3",new Seat("G3","VIP",8000,true));
        seat_list.put("G4",new Seat("G4","VIP",8000,true));
        seat_list.put("G5",new Seat("G5","VIP",8000,true));
        seat_list.put("G6",new Seat("G6","VIP",8000,true));
        seat_list.put("G7",new Seat("G7","VIP",8000,true));
        seat_list.put("G8",new Seat("G8","VIP",8000,true));
        seat_list.put("G9",new Seat("G9","VIP",8000,true));
        seat_list.put("G10",new Seat("G10","VIP",8000,true));
        
        
        seat_list.put("H1",new Seat("H1","Couple",12000,true));
        seat_list.put("H2",new Seat("H2","Couple",12000,true));
        seat_list.put("H3",new Seat("H3","Couple",12000,true));
        seat_list.put("H4",new Seat("H4","Couple",12000,true));
        seat_list.put("H5",new Seat("H5","Couple",12000,true));
        
        seat_list.put("I1",new Seat("I1","Couple",12000,true));
        seat_list.put("I2",new Seat("I2","Couple",12000,true));
        seat_list.put("I3",new Seat("I3","Couple",12000,true));
        seat_list.put("I4",new Seat("I4","Couple",12000,true));
        seat_list.put("I5",new Seat("I5","Couple",12000,true));
        
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        jButton34 = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        jButton36 = new javax.swing.JButton();
        jButton37 = new javax.swing.JButton();
        jButton38 = new javax.swing.JButton();
        jButton39 = new javax.swing.JButton();
        jButton40 = new javax.swing.JButton();
        jButton41 = new javax.swing.JButton();
        jButton42 = new javax.swing.JButton();
        jButton43 = new javax.swing.JButton();
        jButton44 = new javax.swing.JButton();
        jButton45 = new javax.swing.JButton();
        jButton46 = new javax.swing.JButton();
        jButton47 = new javax.swing.JButton();
        jButton48 = new javax.swing.JButton();
        jButton49 = new javax.swing.JButton();
        jButton50 = new javax.swing.JButton();
        jButton51 = new javax.swing.JButton();
        jButton52 = new javax.swing.JButton();
        jButton53 = new javax.swing.JButton();
        jButton54 = new javax.swing.JButton();
        jButton55 = new javax.swing.JButton();
        jButton56 = new javax.swing.JButton();
        jButton57 = new javax.swing.JButton();
        jButton58 = new javax.swing.JButton();
        jButton59 = new javax.swing.JButton();
        jButton60 = new javax.swing.JButton();
        jButton61 = new javax.swing.JButton();
        jButton62 = new javax.swing.JButton();
        jButton63 = new javax.swing.JButton();
        jButton64 = new javax.swing.JButton();
        jButton65 = new javax.swing.JButton();
        jButton66 = new javax.swing.JButton();
        jButton67 = new javax.swing.JButton();
        jButton68 = new javax.swing.JButton();
        jButton69 = new javax.swing.JButton();
        jButton70 = new javax.swing.JButton();
        jButton71 = new javax.swing.JButton();
        jButton72 = new javax.swing.JButton();
        jButton73 = new javax.swing.JButton();
        jButton74 = new javax.swing.JButton();
        jButton75 = new javax.swing.JButton();
        jButton76 = new javax.swing.JButton();
        jButton77 = new javax.swing.JButton();
        jButton78 = new javax.swing.JButton();
        jButton79 = new javax.swing.JButton();
        jButton80 = new javax.swing.JButton();
        jButton101 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("A1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("A2");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("A3");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("A4");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("A5");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("A6");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("A7");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("A8");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setText("A9");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setText("A10");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setText("B1");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setText("B2");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setText("B3");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setText("B4");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.setText("B5");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jButton16.setText("B6");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton17.setText("B7");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton18.setText("B8");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jButton19.setText("B9");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jButton20.setText("B10");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        jButton21.setText("C1");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        jButton22.setText("C2");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jButton23.setText("C3");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        jButton24.setText("C4");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        jButton25.setText("C5");
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });

        jButton26.setText("C6");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        jButton27.setText("C7");
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });

        jButton28.setText("C8");
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });

        jButton29.setText("C9");
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });

        jButton30.setText("C10");
        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });

        jButton31.setText("D1");
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });

        jButton32.setText("D2");
        jButton32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton32ActionPerformed(evt);
            }
        });

        jButton33.setText("D3");
        jButton33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton33ActionPerformed(evt);
            }
        });

        jButton34.setText("D4");
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });

        jButton35.setText("D5");
        jButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton35ActionPerformed(evt);
            }
        });

        jButton36.setText("D6");
        jButton36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton36ActionPerformed(evt);
            }
        });

        jButton37.setText("D7");
        jButton37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton37ActionPerformed(evt);
            }
        });

        jButton38.setText("D8");
        jButton38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton38ActionPerformed(evt);
            }
        });

        jButton39.setText("D9");
        jButton39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton39ActionPerformed(evt);
            }
        });

        jButton40.setText("D10");
        jButton40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton40ActionPerformed(evt);
            }
        });

        jButton41.setText("E1");
        jButton41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton41ActionPerformed(evt);
            }
        });

        jButton42.setText("E2");
        jButton42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton42ActionPerformed(evt);
            }
        });

        jButton43.setText("E3");
        jButton43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton43ActionPerformed(evt);
            }
        });

        jButton44.setText("E4");
        jButton44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton44ActionPerformed(evt);
            }
        });

        jButton45.setText("E5");
        jButton45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton45ActionPerformed(evt);
            }
        });

        jButton46.setText("E6");
        jButton46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton46ActionPerformed(evt);
            }
        });

        jButton47.setText("E7");
        jButton47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton47ActionPerformed(evt);
            }
        });

        jButton48.setText("E8");
        jButton48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton48ActionPerformed(evt);
            }
        });

        jButton49.setText("E9");
        jButton49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton49ActionPerformed(evt);
            }
        });

        jButton50.setText("E10");
        jButton50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton50ActionPerformed(evt);
            }
        });

        jButton51.setText("F1");
        jButton51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton51ActionPerformed(evt);
            }
        });

        jButton52.setText("F2");
        jButton52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton52ActionPerformed(evt);
            }
        });

        jButton53.setText("F3");
        jButton53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton53ActionPerformed(evt);
            }
        });

        jButton54.setText("F4");
        jButton54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton54ActionPerformed(evt);
            }
        });

        jButton55.setText("F5");
        jButton55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton55ActionPerformed(evt);
            }
        });

        jButton56.setText("F6");
        jButton56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton56ActionPerformed(evt);
            }
        });

        jButton57.setText("F7");
        jButton57.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton57ActionPerformed(evt);
            }
        });

        jButton58.setText("F8");
        jButton58.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton58ActionPerformed(evt);
            }
        });

        jButton59.setText("F9");
        jButton59.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton59ActionPerformed(evt);
            }
        });

        jButton60.setText("F10");
        jButton60.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton60ActionPerformed(evt);
            }
        });

        jButton61.setText("G1");
        jButton61.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton61ActionPerformed(evt);
            }
        });

        jButton62.setText("G2");
        jButton62.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton62ActionPerformed(evt);
            }
        });

        jButton63.setText("G3");
        jButton63.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton63ActionPerformed(evt);
            }
        });

        jButton64.setText("G4");
        jButton64.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton64ActionPerformed(evt);
            }
        });

        jButton65.setText("G5");
        jButton65.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton65ActionPerformed(evt);
            }
        });

        jButton66.setText("G6");
        jButton66.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton66ActionPerformed(evt);
            }
        });

        jButton67.setText("G7");
        jButton67.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton67ActionPerformed(evt);
            }
        });

        jButton68.setText("G8");
        jButton68.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton68ActionPerformed(evt);
            }
        });

        jButton69.setText("G9");
        jButton69.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton69ActionPerformed(evt);
            }
        });

        jButton70.setText("G10");
        jButton70.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton70ActionPerformed(evt);
            }
        });

        jButton71.setText("H1");
        jButton71.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton71ActionPerformed(evt);
            }
        });

        jButton72.setText("H2");
        jButton72.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton72ActionPerformed(evt);
            }
        });

        jButton73.setText("H3");
        jButton73.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton73ActionPerformed(evt);
            }
        });

        jButton74.setText("H4");
        jButton74.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton74ActionPerformed(evt);
            }
        });

        jButton75.setText("H5");
        jButton75.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton75ActionPerformed(evt);
            }
        });

        jButton76.setText("I1");
        jButton76.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton76ActionPerformed(evt);
            }
        });

        jButton77.setText("I2");
        jButton77.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton77ActionPerformed(evt);
            }
        });

        jButton78.setText("I3");
        jButton78.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton78ActionPerformed(evt);
            }
        });

        jButton79.setText("I4");
        jButton79.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton79ActionPerformed(evt);
            }
        });

        jButton80.setText("I5");
        jButton80.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton80ActionPerformed(evt);
            }
        });

        jButton101.setBackground(new java.awt.Color(153, 153, 153));
        jButton101.setText("Confirm");
        jButton101.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton101ActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/seats.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 651, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(103, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton41, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton42, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton43, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton44, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton45, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton46, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton47, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton48, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton49, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton50, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton32, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton33, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton34, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton35, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton36, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton37, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton38, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton39, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton40, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton25, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton27, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton28, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton29, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton30, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton51, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton52, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton53, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton54, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton55, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton56, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton57, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton58, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton59, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton60, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton61, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton62, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton63, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton64, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton65, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton66, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jButton73, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButton76, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton71, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton72, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                                    .addComponent(jButton77, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addComponent(jButton78, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton67, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton68, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jButton74, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton69, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton70, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jButton75, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton79, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton80, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButton101, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton25, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton27, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton28, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton29, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton30, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton32, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton33, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton34, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton35, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton36, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton37, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton38, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton39, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton40, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton41, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton42, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton43, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton44, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton45, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton46, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton47, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton48, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton49, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton50, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton51, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton52, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton53, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton54, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton55, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton56, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton57, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton58, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton59, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton60, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton61, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton62, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton63, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton64, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton65, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton66, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton67, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton68, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton69, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton70, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton71, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                            .addComponent(jButton72, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton73, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton75, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton74, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton79, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jButton76, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                                .addComponent(jButton77, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton78, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton80, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton101, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(301, 301, 301))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(141, 141, 141))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="A1";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton1);
        
        selectedSeat=jButton1;
        
        }
        else{
             String seatNo="A1";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton1);
            sold_seat_list.remove("A1");
           
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="A2";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton2);
        sold_seat_list.add("A2");
        selectedSeat=jButton2;
       
        }
        else{
             String seatNo="A2";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton2);
            sold_seat_list.remove("A2");
            
            
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton101ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton101ActionPerformed
        // TODO add your handling code here:
        //update database data
        JOptionPane.showMessageDialog(null,selectedSeat);
        String seatNo=selectedSeat.getText();
        
        price=seat_list.get(seatNo).getPrice();
        
        this.dispose();
        UserDashboard userDb=new UserDashboard();
        userDb.setVisible(true);
        
        
    }//GEN-LAST:event_jButton101ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="A3";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton3);
        sold_seat_list.add("A3");
        selectedSeat=jButton3;
       
        }
        else{
             String seatNo="A3";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton3);
            sold_seat_list.remove("A3");
            
        }
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="A4";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton4);
        sold_seat_list.add("A4");
        selectedSeat=jButton4;
       
        }
        else{
             String seatNo="A4";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton4);
            sold_seat_list.remove("A4");
            
        }
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="A5";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton5);
        sold_seat_list.add("A5");
        selectedSeat=jButton5;
       
        }
        else{
             String seatNo="A5";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton5);
            sold_seat_list.remove("A5");
            
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="A6";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton6);
        sold_seat_list.add("A6");
        selectedSeat=jButton6;
       
        }
        else{
             String seatNo="A6";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton6);
            sold_seat_list.remove("A6");
            
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="A7";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton7);
        sold_seat_list.add("A7");
        selectedSeat=jButton7;
       
        }
        else{
             String seatNo="A7";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton7);
            sold_seat_list.remove("A7");
            
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="A8";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton8);
        sold_seat_list.add("A8");
        selectedSeat=jButton8;
       
        }
        else{
             String seatNo="A8";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton8);
            sold_seat_list.remove("A8");
            
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="A9";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton9);
        sold_seat_list.add("A9");
        selectedSeat=jButton9;
       
        }
        else{
             String seatNo="A9";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton9);
            sold_seat_list.remove("A9");
            
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="A10";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton10);
        sold_seat_list.add("A10");
        selectedSeat=jButton10;
       
        }
        else{
             String seatNo="A10";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton10);
            sold_seat_list.remove("A10");
            
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="B1";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton11);
        sold_seat_list.add("B1");
        selectedSeat=jButton11;
       
        }
        else{
             String seatNo="B1";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton11);
            sold_seat_list.remove("B1");
            
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="B2";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton12);
        sold_seat_list.add("B2");
        selectedSeat=jButton12;
       
        }
        else{
             String seatNo="B2";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton12);
            sold_seat_list.remove("B2");
            
        }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="B3";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton13);
        sold_seat_list.add("B3");
        selectedSeat=jButton13;
       
        }
        else{
             String seatNo="B3";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton13);
            sold_seat_list.remove("B3");
            
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="B4";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton14);
        sold_seat_list.add("B4");
        selectedSeat=jButton14;
       
        }
        else{
             String seatNo="B4";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton14);
            sold_seat_list.remove("B4");
            
        }
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="B5";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton15);
        sold_seat_list.add("B5");
        selectedSeat=jButton15;
       
        }
        else{
             String seatNo="B5";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton15);
            sold_seat_list.remove("B5");
            
        }
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="B6";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton16);
        sold_seat_list.add("B6");
        selectedSeat=jButton16;
       
        }
        else{
             String seatNo="B6";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton16);
            sold_seat_list.remove("B6");
            
        }
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="B7";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton17);
        sold_seat_list.add("B7");
        selectedSeat=jButton17;
       
        }
        else{
             String seatNo="B7";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton17);
            sold_seat_list.remove("B7");
            
        }
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="B8";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton18);
        sold_seat_list.add("B8");
        selectedSeat=jButton18;
       
        }
        else{
             String seatNo="B8";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton18);
            sold_seat_list.remove("B8");
            
        }
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="B9";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton19);
        sold_seat_list.add("B9");
        selectedSeat=jButton19;
       
        }
        else{
             String seatNo="B9";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton19);
            sold_seat_list.remove("B9");
            
        }
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="B10";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton20);
        sold_seat_list.add("B10");
        selectedSeat=jButton20;
       
        }
        else{
             String seatNo="B10";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton20);
            sold_seat_list.remove("B10");
            
        }
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="C1";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton21);
        sold_seat_list.add("C1");
        selectedSeat=jButton21;
       
        }
        else{
             String seatNo="C1";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton21);
            sold_seat_list.remove("C1");
            
        }
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="C2";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton22);
        sold_seat_list.add("C2");
        selectedSeat=jButton22;
       
        }
        else{
             String seatNo="C2";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton22);
            sold_seat_list.remove("C2");
            
        }
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="C3";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton23);
        sold_seat_list.add("C3");
        selectedSeat=jButton23;
       
        }
        else{
             String seatNo="C3";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton23);
            sold_seat_list.remove("C3");
            
        }
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="C4";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton24);
        sold_seat_list.add("C4");
        selectedSeat=jButton24;
       
        }
        else{
             String seatNo="C4";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton24);
            sold_seat_list.remove("C4");
            
        }
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="C5";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton25);
        sold_seat_list.add("C5");
        selectedSeat=jButton25;
       
        }
        else{
             String seatNo="C5";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton25);
            sold_seat_list.remove("C5");
            
        }
    }//GEN-LAST:event_jButton25ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="C6";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton26);
        sold_seat_list.add("C6");
        selectedSeat=jButton26;
       
        }
        else{
             String seatNo="C6";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton26);
            sold_seat_list.remove("C6");
            
        }
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="C7";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton27);
        sold_seat_list.add("C7");
        selectedSeat=jButton27;
       
        }
        else{
             String seatNo="C7";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton27);
            sold_seat_list.remove("C7");
            
        }
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="C8";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton28);
        sold_seat_list.add("C8");
        selectedSeat=jButton28;
       
        }
        else{
             String seatNo="C8";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton28);
            sold_seat_list.remove("C8");
            
        }
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="C9";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton29);
        sold_seat_list.add("C9");
        selectedSeat=jButton29;
       
        }
        else{
             String seatNo="C9";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton29);
            sold_seat_list.remove("C9");
            
        }
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="C10";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton30);
        sold_seat_list.add("C10");
        selectedSeat=jButton30;
       
        }
        else{
             String seatNo="C10";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton30);
            sold_seat_list.remove("C10");
            
        }
    }//GEN-LAST:event_jButton30ActionPerformed

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="D1";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton31);
        sold_seat_list.add("D1");
        selectedSeat=jButton31;
       
        }
        else{
             String seatNo="D1";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton31);
            sold_seat_list.remove("D1");
            
        }
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="D2";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton32);
        sold_seat_list.add("D2");
        selectedSeat=jButton32;
       
        }
        else{
             String seatNo="D2";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton32);
            sold_seat_list.remove("D2");
            
        }
    }//GEN-LAST:event_jButton32ActionPerformed

    private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="D3";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton33);
        sold_seat_list.add("D3");
        selectedSeat=jButton33;
       
        }
        else{
             String seatNo="D3";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton33);
            sold_seat_list.remove("D3");
            
        }
    }//GEN-LAST:event_jButton33ActionPerformed

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="D4";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton34);
        sold_seat_list.add("D4");
        selectedSeat=jButton34;
       
        }
        else{
             String seatNo="D4";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton34);
            sold_seat_list.remove("D4");
            
        }
    }//GEN-LAST:event_jButton34ActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="D5";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton35);
        sold_seat_list.add("D5");
        selectedSeat=jButton35;
       
        }
        else{
             String seatNo="D5";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton35);
            sold_seat_list.remove("D5");
            
        }
    }//GEN-LAST:event_jButton35ActionPerformed

    private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="D6";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton36);
        sold_seat_list.add("D6");
        selectedSeat=jButton36;
       
        }
        else{
             String seatNo="D6";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton36);
            sold_seat_list.remove("D6");
            
        }
    }//GEN-LAST:event_jButton36ActionPerformed

    private void jButton37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton37ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="D7";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton37);
        sold_seat_list.add("D7");
        selectedSeat=jButton37;
       
        }
        else{
             String seatNo="D7";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton37);
            sold_seat_list.remove("D7");
            
        }
    }//GEN-LAST:event_jButton37ActionPerformed

    private void jButton38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton38ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="D8";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton38);
        sold_seat_list.add("D8");
        selectedSeat=jButton38;
       
        }
        else{
             String seatNo="D8";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton38);
            sold_seat_list.remove("D8");
            
        }
    }//GEN-LAST:event_jButton38ActionPerformed

    private void jButton39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton39ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="D9";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton39);
        sold_seat_list.add("D9");
        selectedSeat=jButton39;
       
        }
        else{
             String seatNo="D9";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton39);
            sold_seat_list.remove("D9");
            
        }
    }//GEN-LAST:event_jButton39ActionPerformed

    private void jButton40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton40ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="D10";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton40);
        sold_seat_list.add("D10");
        selectedSeat=jButton40;
       
        }
        else{
             String seatNo="D10";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton40);
            sold_seat_list.remove("D10");
            
        }
    }//GEN-LAST:event_jButton40ActionPerformed

    private void jButton41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton41ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="E1";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton41);
        sold_seat_list.add("E1");
        selectedSeat=jButton41;
       
        }
        else{
             String seatNo="E1";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton41);
            sold_seat_list.remove("E1");
            
        }
    }//GEN-LAST:event_jButton41ActionPerformed

    private void jButton42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton42ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="E2";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton42);
        sold_seat_list.add("E2");
        selectedSeat=jButton42;
       
        }
        else{
             String seatNo="E2";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton42);
            sold_seat_list.remove("E2");
            
        }
    }//GEN-LAST:event_jButton42ActionPerformed

    private void jButton43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton43ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="E3";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton43);
        sold_seat_list.add("E3");
        selectedSeat=jButton43;
       
        }
        else{
             String seatNo="E3";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton43);
            sold_seat_list.remove("E3");
            
        }
    }//GEN-LAST:event_jButton43ActionPerformed

    private void jButton44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton44ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="E4";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton44);
        sold_seat_list.add("E4");
        selectedSeat=jButton44;
       
        }
        else{
             String seatNo="E4";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton44);
            sold_seat_list.remove("E4");
            
        }
    }//GEN-LAST:event_jButton44ActionPerformed

    private void jButton45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton45ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="E5";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton45);
        sold_seat_list.add("E5");
        selectedSeat=jButton45;
       
        }
        else{
             String seatNo="E5";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton45);
            sold_seat_list.remove("E5");
            
        }
    }//GEN-LAST:event_jButton45ActionPerformed

    private void jButton46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton46ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="E6";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton46);
        sold_seat_list.add("E6");
        selectedSeat=jButton46;
       
        }
        else{
             String seatNo="E6";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton46);
            sold_seat_list.remove("E6");
            
        }
    }//GEN-LAST:event_jButton46ActionPerformed

    private void jButton47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton47ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="E7";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton47);
        sold_seat_list.add("E7");
        selectedSeat=jButton47;
       
        }
        else{
             String seatNo="E7";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton47);
            sold_seat_list.remove("E7");
            
        }
    }//GEN-LAST:event_jButton47ActionPerformed

    private void jButton48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton48ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="E8";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton48);
        sold_seat_list.add("E8");
        selectedSeat=jButton48;
       
        }
        else{
             String seatNo="E8";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton48);
            sold_seat_list.remove("E8");
            
        }
    }//GEN-LAST:event_jButton48ActionPerformed

    private void jButton49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton49ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="E9";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton49);
        sold_seat_list.add("E9");
        selectedSeat=jButton49;
       
        }
        else{
             String seatNo="E9";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton49);
            sold_seat_list.remove("E9");
            
        }
    }//GEN-LAST:event_jButton49ActionPerformed

    private void jButton50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton50ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="E10";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton50);
        sold_seat_list.add("E10");
        selectedSeat=jButton50;
       
        }
        else{
             String seatNo="E10";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton50);
            sold_seat_list.remove("E10");
            
        }
    }//GEN-LAST:event_jButton50ActionPerformed

    private void jButton51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton51ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="F1";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton51);
        sold_seat_list.add("F1");
        selectedSeat=jButton51;
       
        }
        else{
             String seatNo="F1";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton51);
            sold_seat_list.remove("F1");
            
        }
    }//GEN-LAST:event_jButton51ActionPerformed

    private void jButton52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton52ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="F2";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton52);
        sold_seat_list.add("F2");
        selectedSeat=jButton52;
       
        }
        else{
             String seatNo="F2";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton52);
            sold_seat_list.remove("F2");
            
        }
    }//GEN-LAST:event_jButton52ActionPerformed

    private void jButton53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton53ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="F3";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton53);
        sold_seat_list.add("F3");
        selectedSeat=jButton53;
       
        }
        else{
             String seatNo="F3";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton53);
            sold_seat_list.remove("F3");
            
        }
    }//GEN-LAST:event_jButton53ActionPerformed

    private void jButton54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton54ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="F4";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton54);
        sold_seat_list.add("F4");
        selectedSeat=jButton54;
       
        }
        else{
             String seatNo="F4";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton54);
            sold_seat_list.remove("F4");
            
        }
    }//GEN-LAST:event_jButton54ActionPerformed

    private void jButton55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton55ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="F5";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton55);
        sold_seat_list.add("F5");
        selectedSeat=jButton55;
       
        }
        else{
             String seatNo="F5";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton55);
            sold_seat_list.remove("F5");
            
        }
    }//GEN-LAST:event_jButton55ActionPerformed

    private void jButton56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton56ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="F6";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton56);
        sold_seat_list.add("F6");
        selectedSeat=jButton56;
       
        }
        else{
             String seatNo="F6";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton56);
            sold_seat_list.remove("F6");
            
        }
    }//GEN-LAST:event_jButton56ActionPerformed

    private void jButton57ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton57ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="F7";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton57);
        sold_seat_list.add("F7");
        selectedSeat=jButton57;
       
        }
        else{
             String seatNo="F7";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton57);
            sold_seat_list.remove("F7");
            
        }
    }//GEN-LAST:event_jButton57ActionPerformed

    private void jButton58ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton58ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="F8";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton58);
        sold_seat_list.add("F8");
        selectedSeat=jButton58;
       
        }
        else{
             String seatNo="F8";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton58);
            sold_seat_list.remove("F8");
            
        }
    }//GEN-LAST:event_jButton58ActionPerformed

    private void jButton59ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton59ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="F9";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton59);
        sold_seat_list.add("F9");
        selectedSeat=jButton59;
       
        }
        else{
             String seatNo="F9";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton59);
            sold_seat_list.remove("F9");
            
        }
    }//GEN-LAST:event_jButton59ActionPerformed

    private void jButton60ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton60ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="F10";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton60);
        sold_seat_list.add("F10");
        selectedSeat=jButton60;
       
        }
        else{
             String seatNo="F10";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton60);
            sold_seat_list.remove("F10");
            
        }
    }//GEN-LAST:event_jButton60ActionPerformed

    private void jButton61ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton61ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="G1";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton61);
        sold_seat_list.add("G1");
        selectedSeat=jButton61;
       
        }
        else{
             String seatNo="G1";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton61);
            sold_seat_list.remove("G1");
            
        }
    }//GEN-LAST:event_jButton61ActionPerformed

    private void jButton62ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton62ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="G2";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton62);
        sold_seat_list.add("G2");
        selectedSeat=jButton62;
       
        }
        else{
             String seatNo="G2";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton62);
            sold_seat_list.remove("G2");
            
        }
    }//GEN-LAST:event_jButton62ActionPerformed

    private void jButton63ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton63ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="G3";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton63);
        sold_seat_list.add("G3");
        selectedSeat=jButton63;
       
        }
        else{
             String seatNo="G3";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton63);
            sold_seat_list.remove("G3");
            
        }
    }//GEN-LAST:event_jButton63ActionPerformed

    private void jButton64ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton64ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="G4";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton64);
        sold_seat_list.add("G4");
        selectedSeat=jButton64;
       
        }
        else{
             String seatNo="G4";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton64);
            sold_seat_list.remove("G4");
            
        }
    }//GEN-LAST:event_jButton64ActionPerformed

    private void jButton65ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton65ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="G5";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton65);
        sold_seat_list.add("G5");
        selectedSeat=jButton65;
       
        }
        else{
             String seatNo="G5";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton65);
            sold_seat_list.remove("G5");
            
        }
    }//GEN-LAST:event_jButton65ActionPerformed

    private void jButton66ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton66ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="G6";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton66);
        sold_seat_list.add("G6");
        selectedSeat=jButton66;
       
        }
        else{
             String seatNo="G6";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton66);
            sold_seat_list.remove("G6");
            
        }
    }//GEN-LAST:event_jButton66ActionPerformed

    private void jButton67ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton67ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="G7";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton67);
        sold_seat_list.add("G7");
        selectedSeat=jButton67;
       
        }
        else{
             String seatNo="G7";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton67);
            sold_seat_list.remove("G7");
            
        }
    }//GEN-LAST:event_jButton67ActionPerformed

    private void jButton68ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton68ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="G8";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton68);
        sold_seat_list.add("G8");
        selectedSeat=jButton68;
       
        }
        else{
             String seatNo="G8";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton68);
            sold_seat_list.remove("G8");
            
        }
    }//GEN-LAST:event_jButton68ActionPerformed

    private void jButton69ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton69ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="G9";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton69);
        sold_seat_list.add("G9");
        selectedSeat=jButton69;
       
        }
        else{
             String seatNo="G9";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton69);
            sold_seat_list.remove("G9");
            
        }
    }//GEN-LAST:event_jButton69ActionPerformed

    private void jButton70ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton70ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="G10";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton70);
        sold_seat_list.add("G10");
        selectedSeat=jButton70;
       
        }
        else{
             String seatNo="G10";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton70);
            sold_seat_list.remove("G10");
            
        }
    }//GEN-LAST:event_jButton70ActionPerformed

    private void jButton71ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton71ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="H1";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton71);
        sold_seat_list.add("H1");
        selectedSeat=jButton71;
       
        }
        else{
             String seatNo="H1";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton71);
            sold_seat_list.remove("H1");
            
        }
    }//GEN-LAST:event_jButton71ActionPerformed

    private void jButton72ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton72ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="H2";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton72);
        sold_seat_list.add("H2");
        selectedSeat=jButton72;
       
        }
        else{
             String seatNo="H2";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton72);
            sold_seat_list.remove("H2");
            
        }
    }//GEN-LAST:event_jButton72ActionPerformed

    private void jButton73ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton73ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="H3";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton73);
        sold_seat_list.add("H3");
        selectedSeat=jButton73;
       
        }
        else{
             String seatNo="H3";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton73);
            sold_seat_list.remove("H3");
            
        }
    }//GEN-LAST:event_jButton73ActionPerformed

    private void jButton74ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton74ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="H4";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton74);
        sold_seat_list.add("H4");
        selectedSeat=jButton74;
       
        }
        else{
             String seatNo="H4";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton74);
            sold_seat_list.remove("H4");
            
        }
    }//GEN-LAST:event_jButton74ActionPerformed

    private void jButton75ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton75ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="H5";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton75);
        sold_seat_list.add("H5");
        selectedSeat=jButton75;
       
        }
        else{
             String seatNo="H5";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton75);
            sold_seat_list.remove("H5");
            
        }
    }//GEN-LAST:event_jButton75ActionPerformed

    private void jButton76ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton76ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="I1";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton76);
        sold_seat_list.add("I1");
        selectedSeat=jButton76;
       
        }
        else{
             String seatNo="I1";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton76);
            sold_seat_list.remove("I1");
            
        }
    }//GEN-LAST:event_jButton76ActionPerformed

    private void jButton77ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton77ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="I2";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton77);
        sold_seat_list.add("I2");
        selectedSeat=jButton77;
       
        }
        else{
             String seatNo="I2";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton77);
            sold_seat_list.remove("I2");
            
        }
    }//GEN-LAST:event_jButton77ActionPerformed

    private void jButton78ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton78ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="I3";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton78);
        sold_seat_list.add("I3");
        selectedSeat=jButton78;
      
        }
        else{
             String seatNo="I3";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton78);
            sold_seat_list.remove("I3");
            
        }
    }//GEN-LAST:event_jButton78ActionPerformed

    private void jButton79ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton79ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="I4";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton79);
        sold_seat_list.add("I4");
        selectedSeat=jButton79;
       
        }
        else{
             String seatNo="I4";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton79);
            sold_seat_list.remove("I4");
            
        }
    }//GEN-LAST:event_jButton79ActionPerformed

    private void jButton80ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton80ActionPerformed
        // TODO add your handling code here:
        click_count++;
        
        if(click_count%2==1){
        String seatNo="I5";
        Seat seat=seat_list.get(seatNo);
        seat.setSelected(true);
        addSeatButtonColor(jButton80);
        sold_seat_list.add("I5");
        selectedSeat=jButton80;
       
        }
        else{
             String seatNo="I5";
            Seat seat=seat_list.get(seatNo);
            seat.setSelected(false);
            removeSeatButtonColor(jButton80);
            sold_seat_list.remove("I5");
            
        }
    }//GEN-LAST:event_jButton80ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SeatPlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SeatPlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SeatPlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SeatPlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SeatPlan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton101;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton40;
    private javax.swing.JButton jButton41;
    private javax.swing.JButton jButton42;
    private javax.swing.JButton jButton43;
    private javax.swing.JButton jButton44;
    private javax.swing.JButton jButton45;
    private javax.swing.JButton jButton46;
    private javax.swing.JButton jButton47;
    private javax.swing.JButton jButton48;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton50;
    private javax.swing.JButton jButton51;
    private javax.swing.JButton jButton52;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton54;
    private javax.swing.JButton jButton55;
    private javax.swing.JButton jButton56;
    private javax.swing.JButton jButton57;
    private javax.swing.JButton jButton58;
    private javax.swing.JButton jButton59;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton60;
    private javax.swing.JButton jButton61;
    private javax.swing.JButton jButton62;
    private javax.swing.JButton jButton63;
    private javax.swing.JButton jButton64;
    private javax.swing.JButton jButton65;
    private javax.swing.JButton jButton66;
    private javax.swing.JButton jButton67;
    private javax.swing.JButton jButton68;
    private javax.swing.JButton jButton69;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton70;
    private javax.swing.JButton jButton71;
    private javax.swing.JButton jButton72;
    private javax.swing.JButton jButton73;
    private javax.swing.JButton jButton74;
    private javax.swing.JButton jButton75;
    private javax.swing.JButton jButton76;
    private javax.swing.JButton jButton77;
    private javax.swing.JButton jButton78;
    private javax.swing.JButton jButton79;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton80;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

    private void changeSeatButtonColor(JButton btn) {
        btn.setBackground(Color.RED);
    }

    private void addSeatButtonColor(JButton btn) {
        btn.setBackground(Color.red);
    }

    private void removeSeatButtonColor(JButton btn) {
        btn.setBackground(Color.LIGHT_GRAY);
    }
}
