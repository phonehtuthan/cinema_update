/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cinema;
import java.sql.*;
/**
 *
 * @author nc
 */
public class Database {
    
    public Connection getConnected(){
        
        Connection conn=null;
        
        try{
            
            Class.forName("org.sqlite.JDBC");
            conn=DriverManager.getConnection("jdbc:sqlite:cinemadb.db");
            
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        return conn;
    }
    
}
